import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;
import javax.imageio.ImageIO;

/*
 * In order to run this program, the only requirement is to
 * compile this java, and to edit the file directories in order
 * to match your system and the image file.
 */

public class Grey extends RecursiveAction {
    private static int THRESHOLD = 100;
    private static BufferedImage image_global;
    BufferedImage img;
    int start;
    int end;

    public Grey(BufferedImage img, int a, int b) {
        this.img = img;
        image_global = img;
        this.start = a;
        this.end = b;
    }

    @Override
    protected void compute() {
        if (end - start < THRESHOLD) {

            int numCols = img.getWidth();

            for (int i = start; i < end; i++) {
                for (int j = 0; j < numCols; j++) {

                    int rgb = img.getRGB(j, i);

                    int a = (rgb >> 24) & 0xff;
                    int r = (rgb >> 16) & 0xff;
                    int g = (rgb >> 8) & 0xff;
                    int b = rgb & 0xff;
                    int avg = (r + g + b) / 3;
                    rgb = (a << 24) | (avg << 16) | (avg << 8) | avg;
                    image_global.setRGB(j, i, rgb);
                }
            }

        } else {
            int mid = (start + end) >>> 1;
            invokeAll(new Grey(img, start, mid), new Grey(img, mid + 1, end));
        }
    }

    public static void main(String[] args) throws IOException {

        System.out.println("Loading image...");
        BufferedImage img = ImageIO.read(new File("/Users/FV/Desktop/final_exam.jpg"));
        System.out.println("Image loaded");

        int numRows = img.getHeight();
        int numCols = img.getWidth();

        greyParallel(img, numRows);
        greySerial(img, numRows, numCols);

    }

    public static void greySerial(BufferedImage img, int numRows, int numCols) throws IOException {

        long start = System.nanoTime();

        System.out.println("Secuential: Started");

        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {

                int rgb = img.getRGB(j, i);

                int a = (rgb >> 24) & 0xff;
                int r = (rgb >> 16) & 0xff;
                int g = (rgb >> 8) & 0xff;
                int b = rgb & 0xff;

                int avg = (r + g + b) / 3;

                rgb = (a << 24) | (avg << 16) | (avg << 8) | avg;
                img.setRGB(j, i, rgb);
            }
        }
        ImageIO.write(img, "jpg", new File("/Users/FV/Desktop/final_exam_grey.jpg"));
        long time = (long) ((System.nanoTime() - start)/ 1e5);
        System.out.println("Secuential Finished in: " + time);
    }

    public static void greyParallel(BufferedImage img, int numRows) throws IOException {

        long start = System.nanoTime();
        System.out.println("Parallel: Started");

        Grey g = new Grey(img, 0, numRows);
        ForkJoinPool pool = new ForkJoinPool();
        pool.invoke(g);
        pool.shutdown();

        ImageIO.write(image_global, "jpg", new File("/Users/FV/Desktop/final_exam_grey.jpg"));
        long time = (long) ((System.nanoTime() - start)/ 1e6);
        System.out.println("Parallel: Finished in: " + time);

    }
}

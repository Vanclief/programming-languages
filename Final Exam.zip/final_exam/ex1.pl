% Franco Valencia A01206630
% How to run: Just run this with swipl and call the function closest(City) or
% neighbors(Hero).
% Example closest(ithanka) = Pylos
% Neightbor (Nestor) = Helen

% Knowledge Base

% Closest City
closest_to(ithaka, pylos).
closest_to(pylos, sparta).
closest_to(argos, mycenae).
closest_to(sparta, argos).
closest_to(mycenae, argos).
closest_to(salamis, athens).
closest_to(athens, salamis).
closest_to(aulis, athens).
closest_to(lokris, aulis).
closest_to(phthia, lokris).
closest_to(krete, salamis).
closest_to(troy, aulis).
closest_to(lykia, krete).

% Alied to
alied(greeks, odysseus).
alied(greeks, penelope).
alied(greeks, nestor).
alied(greeks, diomedes).
alied(greeks, helen).
alied(greeks, menelaos).
alied(greeks, agamemmon).
alied(greeks, klytaimestra).
alied(greeks, greater_aias).
alied(greeks, idomeneus).
alied(greeks, sacrifice_of_iphigenia).
alied(greeks, lesser_aias).
alied(greeks, achilleus).
alied(troyans, hektor).
alied(troyans, prism).
alied(troyans, paris).
alied(troyans, hekebe).
alied(troyans, helen).
alied(troyans, sarpedon).
alied(troyans, glaukos).

% Lives in
lives(odysseus, ithanka).
lives(penelope, ithanka).
lives(nestor, pylos).
lives(diomedes, argos).
lives(helen, sparta).
lives(menelaos, sparta).
lives(agamemmon, mycenae).
lives(klytaimestra, mycenae).
lives(greater_aias, salamis).
lives(idomeneus, krete).
lives(sacrifice_of_iphigenia, aulis).
lives(lesser_aias, lokris).
lives(achilleus, phthia).
lives(hektor, troy).
lives(prism, troy).
lives(paris, troy).
lives(hekebe, troy).
lives(helen, troy).
lives(sarpedon, lykia).
lives(glaukos, lykia).

closest(X) :-
  closest_to(X, Y),
  write(Y).

neighbors(H) :-
  lives(H, X),
  closest_to(X, Y),
  hero(Y, Z),
  write(Z).


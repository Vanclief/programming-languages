#! usr/local/bin/perl
# To run this file, just edit the variable $word
# Example perl ex2.pl with $word = "am" prints salamis, preiam, agamenon
open (FILE, "words.txt");

my $word = "am";
my $r = substr($word, -3);
@rhymes;

for $line(<FILE>){

  @words = split(", ", $line);

  foreach $w(@words) {
    if($w =~ /$r/gi){
      push(@rhymes, "$w ");
    }
  }
}

print "$word rhymes with: \n";
print(@rhymes);
